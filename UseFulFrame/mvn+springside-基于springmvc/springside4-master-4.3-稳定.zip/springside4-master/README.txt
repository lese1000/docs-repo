  SpringSide is a Spring Framework based JavaEE application reference architecture. 
  
  It shows the mainstream technologies and pragmatic practice in JavaEE world.  
  
  It has 4 major examples:
  
  1. Quickstart -- a minimal CRUD Todo-List web application.
  2. Showcase -- demonstrate many other interesting technologies.
  3. BootService -- a Spring Boot based WebService application.
  4. BootMore -- a Spring Boot based WebService application with more samle.
 
-------------------------------
Offical Site: http://springside.io
Document: https://github.com/springside/springside4/wiki