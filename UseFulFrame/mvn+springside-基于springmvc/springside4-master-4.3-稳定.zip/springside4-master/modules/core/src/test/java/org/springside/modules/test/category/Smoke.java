/*******************************************************************************
 * Copyright (c) 2005, 2014 springside.github.io
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 *******************************************************************************/
package org.springside.modules.test.category;

/**
 * 冒烟测试标签, 标识快速运行的关键集成测试用例。
 * 
 * @author calvin
 */
public interface Smoke {
}