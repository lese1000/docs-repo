package org.springside.examples.bootservice.config;

public class Profiles {

	public static final String PRODUCTION = "production";

}
