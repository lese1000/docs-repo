What is more?

1. Use Jetty instead of Tomcat
2. Don't use spring boot parent
2. Use JavaSimon, demo AOP and Servlet mapping definition 