insert into ss_user (id, name) values(1,'Admin');
insert into ss_user (id, name) values(2,'Calvin');

insert into ss_task (id, title, description, user_id) values(1, 'Spring Boot', 'Study Spring Boot', 2);
insert into ss_task (id, title, description, user_id) values(2, 'Thymeleaf', 'Study Thymeleaf', 2);
insert into ss_task (id, title, description, user_id) values(3, 'Graphite', 'Try Graphite', 2);
insert into ss_task (id, title, description, user_id) values(4, 'Logstash', 'Try Logstash', 2);
insert into ss_task (id, title, description, user_id) values(5, 'SpringSide 5.0', 'Release SpringSide 5.0 As soon as posibble.', 2);

