delete from ss_team;
delete from ss_user_role;
delete from ss_role;
delete from ss_user;
