Command to open a H2 web console.

If the maven script doesn't work, get the h2 jar file and type below command:

java -jar h2-1.3.xxx.jar -web -webPort 8090 -browser

See the wiki for details:

https://github.com/springside/springside4/wiki/H2database