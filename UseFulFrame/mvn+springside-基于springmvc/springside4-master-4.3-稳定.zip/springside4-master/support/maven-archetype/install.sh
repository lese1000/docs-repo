#!/bin/bash

echo "[INFO] Install archetype to local repository."

mvn clean install
