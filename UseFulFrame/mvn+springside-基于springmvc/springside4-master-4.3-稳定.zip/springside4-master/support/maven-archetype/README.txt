Maven Archetype template base on Quickstart example to create new project.

See the wiki for details:

https://github.com/springside/springside4/wiki/CreateNewProject