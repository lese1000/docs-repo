JMeter test scripts for showcase example.

See the wiki for details:

https://github.com/springside/springside4/wiki/JMeter 