Server Simulator for performance/stability test, demo base on node.js.

See the wiki for details:

https://github.com/springside/springside4/wiki/nodejs